"use client";

import { useState, useCallback, useEffect } from "react";

// Types
interface Candidate {
  rank: number;
  id: string;
  name: string;
  job_title: string;
  location_city: string;
  location_state: string;
  tier: string;
  algo_score: number;
  ai_score: number;
  final_score: number;
  one_line_summary: string;
  pros: string[];
  cons: string[];
  reasoning: string;
  interview_questions: string[];
  bio_summary: string;
  industries: string;
  sold_to_finance: boolean;
  is_founder: boolean;
  startup_experience: boolean;
  enterprise_experience: boolean;
  missing_required: string[];
  missing_preferred: string[];
  data_completeness: number;
}

interface AlgoPreview {
  id: string;
  name: string;
  job_title: string;
  bio_summary: string;
  algo_score: number;
  sold_to_finance: boolean;
  is_founder: boolean;
  startup_experience: boolean;
}

interface Status {
  status: string;
  phase: string;
  progress: number;
  message: string;
  candidates_total: number;
  candidates_extracted: number;
  candidates_scored: number;
  error: string | null;
  extracted_preview: AlgoPreview[];
  scored_candidates: Candidate[];
  algo_ranked: AlgoPreview[];
}

interface ComparisonResult {
  winner: "A" | "B" | "TIE";
  winner_name: string;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  summary: string;
  candidate_a_strengths: string[];
  candidate_a_weaknesses: string[];
  candidate_b_strengths: string[];
  candidate_b_weaknesses: string[];
  key_differentiator: string;
  recommendation: string;
}

const API_URL = "http://localhost:8000";

// Rotating recruitment tips
const RECRUITMENT_TIPS = [
  { icon: "💡", tip: "Candidates who have sold to CFOs typically close 40% larger deals" },
  { icon: "🎯", tip: "Founder experience often indicates high ownership and scrappiness" },
  { icon: "📊", tip: "Look for quota attainment above 100% - it shows consistent performance" },
  { icon: "🤝", tip: "Enterprise experience + startup mindset = rare and valuable combination" },
  { icon: "⚡", tip: "Short tenures aren't always bad - context matters more than duration" },
  { icon: "🔍", tip: "The best AEs can articulate their sales methodology clearly" },
  { icon: "💰", tip: "High ACV closers typically need 6-12 months to ramp at a new company" },
  { icon: "🚀", tip: "Startup experience builds resilience and adaptability in sales reps" },
  { icon: "📈", tip: "Top performers usually have 3+ years of progressive sales experience" },
  { icon: "🎓", tip: "Industry expertise can accelerate sales cycles significantly" },
  { icon: "🔥", tip: "The best candidates ask great questions during interviews" },
  { icon: "✨", tip: "Cultural fit is just as important as skills and experience" },
];

export default function Home() {
  const [step, setStep] = useState<"landing" | "upload" | "processing" | "results">("landing");
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);
  const [results, setResults] = useState<Candidate[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [loadingQuestions, setLoadingQuestions] = useState(false);

  // Head-to-Head Comparison
  const [compareMode, setCompareMode] = useState(false);
  const [compareSelection, setCompareSelection] = useState<string[]>([]);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [comparingLoading, setComparingLoading] = useState(false);

  // Custom Weights
  const [showWeights, setShowWeights] = useState(false);
  const [weights, setWeights] = useState({
    experience: 1.0,
    financeSales: 1.0,
    founder: 1.0,
    dealSize: 1.0,
    enterprise: 1.0,
  });
  const [rescoreLoading, setRescoreLoading] = useState(false);

  // Rotate tips every 5 seconds during processing
  useEffect(() => {
    if (step !== "processing") return;

    const interval = setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % RECRUITMENT_TIPS.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [step]);

  // Poll for status during processing
  useEffect(() => {
    if (step !== "processing") return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`${API_URL}/api/status`);
        const data: Status = await res.json();
        setStatus(data);

        // Update results as they stream in
        if (data.scored_candidates && data.scored_candidates.length > 0) {
          setResults(data.scored_candidates);
        }

        if (data.status === "complete") {
          clearInterval(interval);
          setStep("results");
        } else if (data.status === "error") {
          clearInterval(interval);
          setError(data.error || "Unknown error");
          setStep("upload");
        }
      } catch (e) {
        console.error(e);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [step]);

  // Handle file drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile?.name.endsWith(".csv")) {
      setFile(droppedFile);
      setError(null);
    } else {
      setError("Please upload a CSV file");
    }
  }, []);

  // Handle file select
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile?.name.endsWith(".csv")) {
      setFile(selectedFile);
      setError(null);
    } else {
      setError("Please upload a CSV file");
    }
  };

  // Upload and start processing
  const handleUpload = async () => {
    if (!file) return;

    try {
      setStep("processing");
      setError(null);
      setCurrentTipIndex(0);
      setResults([]);

      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(`${API_URL}/api/upload`, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        throw new Error("Upload failed");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
      setStep("upload");
    }
  };

  // Lazy load interview questions
  const loadInterviewQuestions = async (candidateId: string) => {
    setLoadingQuestions(true);
    try {
      const res = await fetch(`${API_URL}/api/candidate/${candidateId}/questions`);
      const data = await res.json();

      if (selectedCandidate && data.questions) {
        setSelectedCandidate({
          ...selectedCandidate,
          interview_questions: data.questions,
        });
        // Also update in results
        setResults(results.map(c =>
          c.id === candidateId ? { ...c, interview_questions: data.questions } : c
        ));
      }
    } catch (e) {
      console.error(e);
    }
    setLoadingQuestions(false);
  };

  // Download results CSV
  const handleDownload = async () => {
    window.open(`${API_URL}/api/results/csv`, "_blank");
  };

  // Reset
  const handleReset = () => {
    setStep("upload");
    setFile(null);
    setResults([]);
    setSelectedCandidate(null);
    setStatus(null);
    setError(null);
    setCompareMode(false);
    setCompareSelection([]);
    setComparisonResult(null);
    setShowWeights(false);
  };

  // Toggle compare mode selection
  const toggleCompareSelection = (candidateId: string) => {
    if (compareSelection.includes(candidateId)) {
      setCompareSelection(compareSelection.filter(id => id !== candidateId));
    } else if (compareSelection.length < 2) {
      setCompareSelection([...compareSelection, candidateId]);
    }
  };

  // Run head-to-head comparison
  const handleCompare = async () => {
    if (compareSelection.length !== 2) return;

    setComparingLoading(true);
    try {
      const res = await fetch(`${API_URL}/api/compare`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          candidate_a_id: compareSelection[0],
          candidate_b_id: compareSelection[1],
        }),
      });
      const data = await res.json();
      setComparisonResult(data.comparison);
    } catch (e) {
      console.error(e);
    }
    setComparingLoading(false);
  };

  // Rescore with custom weights
  const handleRescore = async () => {
    setRescoreLoading(true);
    try {
      const res = await fetch(`${API_URL}/api/rescore`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          experience_weight: weights.experience,
          finance_sales_weight: weights.financeSales,
          founder_weight: weights.founder,
          deal_size_weight: weights.dealSize,
          enterprise_weight: weights.enterprise,
        }),
      });
      const data = await res.json();
      setResults(data.candidates);
    } catch (e) {
      console.error(e);
    }
    setRescoreLoading(false);
  };

  // Get tier color class
  const getTierClass = (tier: string) => {
    if (tier.includes("Top")) return "tier-top";
    if (tier.includes("Strong")) return "tier-strong";
    if (tier.includes("Consider")) return "tier-consider";
    return "tier-not-fit";
  };

  const currentTip = RECRUITMENT_TIPS[currentTipIndex];

  return (
    <main className="min-h-screen gradient-bg">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-card mx-4 mt-4 !rounded-2xl px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <span className="text-xl">🎯</span>
            </div>
            <div>
              <h1 className="text-xl font-bold">AI Recruiting</h1>
              <p className="text-xs text-white/60">Intelligent Candidate Ranking</p>
            </div>
          </div>
          {(step === "results" || (step === "processing" && results.length > 0)) && (
            <div className="flex gap-3">
              <button onClick={handleDownload} className="btn-primary !py-2 !px-4 text-sm">
                ⬇️ Export CSV
              </button>
              <button onClick={handleReset} className="btn-primary !py-2 !px-4 text-sm !bg-white/10">
                ↺ New Analysis
              </button>
            </div>
          )}
        </div>
      </header>

      <div className="pt-28 px-4 pb-8 max-w-7xl mx-auto">
        {/* Landing Page - Workflow Selection */}
        {step === "landing" && (
          <div className="animate-fade-in">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-white via-white to-white/60 bg-clip-text text-transparent">
                Welcome to TalentPluto
              </h2>
              <p className="text-xl text-white/60 max-w-2xl mx-auto">
                AI-powered talent matching for the modern recruiter. Choose your workflow below.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {/* Analyze Candidates Card */}
              <div
                onClick={() => setStep("upload")}
                className="group cursor-pointer bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/30 rounded-3xl p-8 hover:border-indigo-500/60 hover:scale-[1.02] transition-all duration-300"
              >
                <div className="text-6xl mb-6">📊</div>
                <h3 className="text-2xl font-bold mb-3 group-hover:text-indigo-400 transition-colors">
                  Analyze Candidates
                </h3>
                <p className="text-white/60 mb-6">
                  Upload a CSV of candidates and get AI-powered scoring, ranking, and comparison.
                  Perfect for batch processing multiple applicants.
                </p>
                <div className="space-y-2 text-sm text-white/50">
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Dual scoring (Algorithmic + AI)
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Head-to-head comparison
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Custom weight adjustments
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Interview questions generated
                  </div>
                </div>
                <div className="mt-6 flex items-center gap-2 text-indigo-400 font-medium group-hover:gap-3 transition-all">
                  Get Started <span>→</span>
                </div>
              </div>

              {/* Onboard Candidate Card */}
              <div
                onClick={() => window.location.href = "/voice"}
                className="group cursor-pointer bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-3xl p-8 hover:border-purple-500/60 hover:scale-[1.02] transition-all duration-300"
              >
                <div className="text-6xl mb-6">🎤</div>
                <h3 className="text-2xl font-bold mb-3 group-hover:text-purple-400 transition-colors">
                  Onboard Candidate
                </h3>
                <p className="text-white/60 mb-6">
                  Let candidates upload their resume and complete their profile through a voice conversation with Pluto.
                </p>
                <div className="space-y-2 text-sm text-white/50">
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> AI resume extraction
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Voice-powered gap filling
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Real-time profile updates
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Natural conversation flow
                  </div>
                </div>
                <div className="mt-6 flex items-center gap-2 text-purple-400 font-medium group-hover:gap-3 transition-all">
                  Start Onboarding <span>→</span>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="mt-16 text-center">
              <p className="text-white/40 text-sm mb-4">Powered by</p>
              <div className="flex justify-center gap-8 text-white/30 text-sm">
                <span>🤖 Gemini 2.5 Flash</span>
                <span>🎙️ VAPI Voice AI</span>
                <span>📊 Smart Scoring</span>
              </div>
            </div>
          </div>
        )}

        {/* Upload Step */}
        {step === "upload" && (
          <div className="animate-fade-in">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white via-white to-white/60 bg-clip-text text-transparent">
                Find Your Perfect Hire
              </h2>
              <p className="text-lg text-white/60 max-w-xl mx-auto">
                Upload your candidate CSV and let AI analyze, score, and rank them
                based on job requirements.
              </p>
            </div>

            <div className="max-w-2xl mx-auto">
              <div
                className={`upload-zone text-center ${isDragging ? "dragging" : ""}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => document.getElementById("file-input")?.click()}
              >
                <input
                  id="file-input"
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                <div className="text-6xl mb-4">{file ? "📄" : "📁"}</div>
                {file ? (
                  <div>
                    <p className="text-xl font-semibold text-white">{file.name}</p>
                    <p className="text-white/50 mt-1">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-xl font-semibold text-white/80">
                      Drop your CSV here
                    </p>
                    <p className="text-white/50 mt-2">or click to browse</p>
                  </div>
                )}
              </div>

              {error && (
                <div className="mt-4 p-4 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-center">
                  {error}
                </div>
              )}

              <button
                onClick={handleUpload}
                disabled={!file}
                className="btn-primary w-full mt-6 text-lg py-4"
              >
                🚀 Analyze Candidates
              </button>

              <div className="mt-8 glass-card p-6">
                <h3 className="font-semibold mb-3 text-white/80">How it works:</h3>
                <div className="space-y-3">
                  {[
                    { icon: "📊", text: "AI extracts key data points from profiles" },
                    { icon: "🎯", text: "Dual scoring: Algorithmic + AI evaluation" },
                    { icon: "📋", text: "Generates pros, cons & interview questions" },
                    { icon: "🏆", text: "Ranks candidates from best to worst fit" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3 text-white/60">
                      <span className="text-xl">{item.icon}</span>
                      <span>{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Processing Step - Shows streaming results */}
        {step === "processing" && status && (
          <div className="animate-fade-in">
            {/* Progress Card */}
            <div className="max-w-2xl mx-auto mb-6">
              <div className="glass-card p-6 text-center">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="text-4xl animate-pulse">
                    {status.phase === "extraction" ? "🔍" : "🧠"}
                  </div>
                  <div className="text-left">
                    <h2 className="text-xl font-bold">{status.message}</h2>
                    <p className="text-sm text-white/60">
                      Extracted: {status.candidates_extracted}/{status.candidates_total} |
                      Scored: {status.candidates_scored}/{status.candidates_total}
                    </p>
                  </div>
                </div>

                <div className="progress-bar mb-2">
                  <div
                    className="progress-fill transition-all duration-500"
                    style={{ width: `${status.progress}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Rotating Tips */}
            <div className="max-w-2xl mx-auto mb-6">
              <div className="glass-card p-4 transition-all duration-500">
                <div className="flex items-center gap-4">
                  <div className="text-3xl">{currentTip.icon}</div>
                  <div>
                    <p className="text-xs text-indigo-400 uppercase tracking-wide mb-1">Recruiting Tip</p>
                    <p className="text-sm text-white/80">{currentTip.tip}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Streaming Results - Show ALL candidates as they're scored */}
            {results.length > 0 && (
              <div className="animate-fade-in">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  {results.length} candidates scored
                  {status.candidates_scored < status.candidates_total && (
                    <span className="text-white/40 text-sm font-normal animate-pulse">
                      (scoring {status.candidates_total - status.candidates_scored} more...)
                    </span>
                  )}
                </h3>

                <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                  {results.map((candidate, i) => (
                    <div
                      key={candidate.id}
                      className={`candidate-card cursor-pointer ${selectedCandidate?.id === candidate.id ? "!border-indigo-500" : ""
                        }`}
                      onClick={() => setSelectedCandidate(candidate)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-xl font-bold text-white/30 w-6">
                          #{candidate.rank}
                        </div>
                        <div
                          className="score-ring bg-white/5 w-12 h-12 text-base"
                          style={{ "--score": `${candidate.final_score}%` } as React.CSSProperties}
                        >
                          {candidate.final_score}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold truncate">{candidate.name}</h4>
                            <span className={`text-xs px-2 py-0.5 rounded-full ${getTierClass(candidate.tier)}`}>
                              {candidate.tier}
                            </span>
                          </div>
                          <p className="text-sm text-white/50 truncate">{candidate.job_title}</p>
                          <p className="text-xs text-white/40 truncate mt-0.5">{candidate.one_line_summary}</p>
                        </div>
                        <div className="text-right text-xs text-white/40">
                          <div>Algo: {candidate.algo_score}</div>
                          <div>AI: {candidate.ai_score}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Algo Preview while extraction happens */}
            {results.length === 0 && status.algo_ranked && status.algo_ranked.length > 0 && (
              <div className="max-w-4xl mx-auto">
                <h3 className="text-lg font-semibold mb-4 text-white/80">
                  ✨ Profiles extracted - AI scoring in progress...
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {status.algo_ranked.slice(0, 6).map((candidate, i) => (
                    <div
                      key={i}
                      className="glass-card p-4 animate-fade-in"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500/30 to-purple-500/30 flex items-center justify-center">
                          <span className="text-lg">{candidate.name.charAt(0)}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold truncate">{candidate.name}</h4>
                            <span className="text-xs px-2 py-0.5 rounded bg-white/10">
                              Algo: {candidate.algo_score}
                            </span>
                          </div>
                          <p className="text-sm text-white/50 truncate">{candidate.job_title}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {candidate.sold_to_finance && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/20 text-green-300">
                                💰 Finance
                              </span>
                            )}
                            {candidate.is_founder && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300">
                                🚀 Founder
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="shimmer w-10 h-10 rounded-full bg-white/5" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Results Step */}
        {step === "results" && (
          <div className="animate-fade-in">
            {/* Summary Stats */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[
                { label: "Total Candidates", value: results.length, icon: "👥" },
                { label: "Strong Fits+", value: results.filter(c => c.tier.includes("Top") || c.tier.includes("Strong")).length, icon: "✅" },
                { label: "CFO Sales Exp", value: results.filter(c => c.sold_to_finance).length, icon: "💰" },
                { label: "Complete Profiles", value: results.filter(c => (c.data_completeness || 0) >= 80).length, icon: "📋" },
              ].map((stat, i) => (
                <div key={i} className="glass-card p-4 text-center animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
                  <div className="text-2xl mb-1">{stat.icon}</div>
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className="text-sm text-white/50">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Action Toolbar */}
            <div className="flex items-center gap-3 mb-6">
              <button
                onClick={() => { setCompareMode(!compareMode); setCompareSelection([]); setComparisonResult(null); }}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${compareMode
                  ? "bg-indigo-500 text-white"
                  : "bg-white/10 hover:bg-white/20 text-white/70"
                  }`}
              >
                ⚔️ {compareMode ? "Exit Compare" : "Compare Candidates"}
              </button>
              <button
                onClick={() => setShowWeights(!showWeights)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${showWeights
                  ? "bg-purple-500 text-white"
                  : "bg-white/10 hover:bg-white/20 text-white/70"
                  }`}
              >
                ⚖️ Custom Weights
              </button>
              {compareMode && compareSelection.length === 2 && (
                <button
                  onClick={handleCompare}
                  disabled={comparingLoading}
                  className="btn-primary px-4 py-2 text-sm flex items-center gap-2"
                >
                  {comparingLoading ? "⏳ Analyzing..." : "🎯 Run Comparison"}
                </button>
              )}
              {compareMode && compareSelection.length > 0 && (
                <span className="text-sm text-white/50">
                  {compareSelection.length}/2 selected
                </span>
              )}
            </div>

            {/* Custom Weights Panel */}
            {showWeights && (
              <div className="glass-card p-4 mb-6 animate-fade-in">
                <h3 className="font-semibold mb-4">⚙️ Adjust Scoring Weights</h3>
                <div className="grid grid-cols-5 gap-4">
                  {[
                    { key: "experience", label: "Experience", icon: "📅" },
                    { key: "financeSales", label: "Finance Sales", icon: "💰" },
                    { key: "founder", label: "Founder DNA", icon: "🚀" },
                    { key: "dealSize", label: "Deal Size", icon: "💎" },
                    { key: "enterprise", label: "Enterprise", icon: "🏢" },
                  ].map((w) => (
                    <div key={w.key} className="text-center">
                      <div className="text-xl mb-1">{w.icon}</div>
                      <div className="text-xs text-white/50 mb-2">{w.label}</div>
                      <input
                        type="range"
                        min="0"
                        max="2"
                        step="0.1"
                        value={weights[w.key as keyof typeof weights]}
                        onChange={(e) => setWeights({ ...weights, [w.key]: parseFloat(e.target.value) })}
                        className="w-full accent-indigo-500"
                      />
                      <div className="text-sm font-mono mt-1">
                        {weights[w.key as keyof typeof weights].toFixed(1)}x
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex justify-end">
                  <button
                    onClick={handleRescore}
                    disabled={rescoreLoading}
                    className="btn-primary px-4 py-2 text-sm"
                  >
                    {rescoreLoading ? "⏳ Recalculating..." : "🔄 Apply Weights"}
                  </button>
                </div>
              </div>
            )}

            {/* Comparison Result Modal */}
            {comparisonResult && (
              <div className="glass-card p-6 mb-6 animate-fade-in border-2 border-indigo-500/50">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-bold">⚔️ Head-to-Head Analysis</h3>
                  <button onClick={() => setComparisonResult(null)} className="text-white/40 hover:text-white">✕</button>
                </div>

                <div className="text-center mb-6">
                  <div className={`inline-block px-6 py-3 rounded-xl ${comparisonResult.winner === "TIE"
                    ? "bg-yellow-500/20 text-yellow-300"
                    : "bg-green-500/20 text-green-300"
                    }`}>
                    <div className="text-sm uppercase tracking-wide opacity-70">Winner</div>
                    <div className="text-2xl font-bold">{comparisonResult.winner_name}</div>
                    <div className="text-sm mt-1">
                      Confidence: <span className={`font-semibold ${comparisonResult.confidence === "HIGH" ? "text-green-400" :
                        comparisonResult.confidence === "MEDIUM" ? "text-yellow-400" : "text-red-400"
                        }`}>{comparisonResult.confidence}</span>
                    </div>
                  </div>
                </div>

                <p className="text-center text-white/70 mb-6">{comparisonResult.summary}</p>

                <div className="grid grid-cols-2 gap-6">
                  {/* Candidate A */}
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-xs">A</span>
                      {results.find(c => c.id === compareSelection[0])?.name}
                    </h4>
                    <div className="mb-3">
                      <div className="text-xs text-green-400 font-semibold mb-1">✓ Strengths</div>
                      <ul className="text-sm space-y-1">
                        {comparisonResult.candidate_a_strengths.map((s, i) => (
                          <li key={i} className="text-white/70">• {s}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <div className="text-xs text-red-400 font-semibold mb-1">✗ Weaknesses</div>
                      <ul className="text-sm space-y-1">
                        {comparisonResult.candidate_a_weaknesses.map((w, i) => (
                          <li key={i} className="text-white/50">• {w}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Candidate B */}
                  <div className="bg-white/5 rounded-xl p-4">
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center text-xs">B</span>
                      {results.find(c => c.id === compareSelection[1])?.name}
                    </h4>
                    <div className="mb-3">
                      <div className="text-xs text-green-400 font-semibold mb-1">✓ Strengths</div>
                      <ul className="text-sm space-y-1">
                        {comparisonResult.candidate_b_strengths.map((s, i) => (
                          <li key={i} className="text-white/70">• {s}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <div className="text-xs text-red-400 font-semibold mb-1">✗ Weaknesses</div>
                      <ul className="text-sm space-y-1">
                        {comparisonResult.candidate_b_weaknesses.map((w, i) => (
                          <li key={i} className="text-white/50">• {w}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-indigo-500/10 rounded-lg border border-indigo-500/30">
                  <div className="text-xs text-indigo-300 font-semibold mb-1">💡 Key Differentiator</div>
                  <p className="text-sm text-white/70">{comparisonResult.key_differentiator}</p>
                </div>

                <div className="mt-3 p-3 bg-green-500/10 rounded-lg border border-green-500/30">
                  <div className="text-xs text-green-300 font-semibold mb-1">📋 Recommendation</div>
                  <p className="text-sm text-white/70">{comparisonResult.recommendation}</p>
                </div>
              </div>
            )}

            <div className="flex gap-6">
              {/* Candidate List */}
              <div className="flex-1">
                <h2 className="text-xl font-bold mb-4">Rankings</h2>
                <div className="space-y-3">
                  {results.map((candidate, i) => (
                    <div
                      key={candidate.id}
                      className={`candidate-card cursor-pointer animate-fade-in ${selectedCandidate?.id === candidate.id ? "!border-indigo-500" : ""
                        }`}
                      onClick={() => setSelectedCandidate(candidate)}
                      style={{ animationDelay: `${i * 0.03}s` }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="text-2xl font-bold text-white/30 w-8">
                          #{candidate.rank}
                        </div>
                        <div
                          className="score-ring bg-white/5"
                          style={{ "--score": `${candidate.final_score}%` } as React.CSSProperties}
                        >
                          {candidate.final_score}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-lg">{candidate.name}</h3>
                            <span className={`text-xs px-2 py-1 rounded-full ${getTierClass(candidate.tier)}`}>
                              {candidate.tier}
                            </span>
                            {/* Data Completeness Badge */}
                            {candidate.missing_required?.length > 0 && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-300" title={`Missing: ${candidate.missing_required.join(", ")}`}>
                                ❌ {candidate.missing_required.length} Required
                              </span>
                            )}
                            {candidate.missing_required?.length === 0 && candidate.missing_preferred?.length > 0 && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300" title={`Missing: ${candidate.missing_preferred.join(", ")}`}>
                                ⚠️ {candidate.missing_preferred.length} Preferred
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-white/60">{candidate.job_title}</p>
                          <p className="text-sm text-white/40 mt-1">{candidate.one_line_summary}</p>
                        </div>
                        <div className="text-right text-sm">
                          <div className="text-white/40">Algo: {candidate.algo_score}</div>
                          <div className="text-white/40">AI: {candidate.ai_score}</div>
                          <div className="text-xs text-white/30 mt-1">{candidate.data_completeness}% data</div>
                        </div>
                        {/* Compare Checkbox - Only for Strong Fit or better */}
                        {compareMode && (candidate.tier.includes("Top") || candidate.tier.includes("Strong")) && (
                          <button
                            onClick={(e) => { e.stopPropagation(); toggleCompareSelection(candidate.id); }}
                            className={`ml-3 w-8 h-8 rounded-lg flex items-center justify-center transition-all ${compareSelection.includes(candidate.id)
                              ? "bg-indigo-500 text-white"
                              : "bg-white/10 text-white/40 hover:bg-white/20"
                              }`}
                          >
                            {compareSelection.includes(candidate.id) ? "✓" : compareSelection.length < 2 ? "+" : ""}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Candidate Detail Panel */}
              {selectedCandidate && (
                <div className="w-96 glass-card p-6 sticky top-28 h-fit max-h-[calc(100vh-8rem)] overflow-y-auto animate-fade-in">
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-sm px-3 py-1 rounded-full ${getTierClass(selectedCandidate.tier)}`}>
                      {selectedCandidate.tier}
                    </span>
                    <button
                      onClick={() => setSelectedCandidate(null)}
                      className="text-white/40 hover:text-white"
                    >
                      ✕
                    </button>
                  </div>

                  <h2 className="text-2xl font-bold">{selectedCandidate.name}</h2>
                  <p className="text-white/60 mb-4">{selectedCandidate.job_title}</p>
                  <p className="text-sm text-white/50 mb-4">
                    📍 {selectedCandidate.location_city}, {selectedCandidate.location_state}
                  </p>

                  {/* Scores */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    {[
                      { label: "Final", value: selectedCandidate.final_score, color: "from-indigo-500 to-purple-500" },
                      { label: "Algo", value: selectedCandidate.algo_score, color: "from-cyan-500 to-blue-500" },
                      { label: "AI", value: selectedCandidate.ai_score, color: "from-pink-500 to-rose-500" },
                    ].map((score, i) => (
                      <div key={i} className="text-center p-3 rounded-xl bg-white/5">
                        <div className={`text-2xl font-bold bg-gradient-to-r ${score.color} bg-clip-text text-transparent`}>
                          {score.value}
                        </div>
                        <div className="text-xs text-white/40">{score.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Data Completeness Indicator */}
                  {(selectedCandidate.missing_required?.length > 0 || selectedCandidate.missing_preferred?.length > 0) && (
                    <div className="mb-4 p-3 rounded-xl bg-white/5 border border-white/10">
                      <div className="flex items-center gap-2 mb-2">
                        <span>{selectedCandidate.data_completeness >= 80 ? "✅" : selectedCandidate.data_completeness >= 50 ? "⚠️" : "🚨"}</span>
                        <span className="text-sm font-semibold">
                          Profile {selectedCandidate.data_completeness}% Complete
                        </span>
                      </div>

                      {/* Missing Required (critical) */}
                      {selectedCandidate.missing_required?.length > 0 && (
                        <div className="mb-2">
                          <p className="text-xs text-red-400 font-semibold mb-1">❌ Missing Required:</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedCandidate.missing_required.map((field: string, i: number) => (
                              <span
                                key={i}
                                className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-300"
                              >
                                {field}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Missing Preferred (nice-to-have) */}
                      {selectedCandidate.missing_preferred?.length > 0 && (
                        <div>
                          <p className="text-xs text-yellow-400 font-semibold mb-1">⚠️ Missing Preferred:</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedCandidate.missing_preferred.map((field: string, i: number) => (
                              <span
                                key={i}
                                className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300"
                              >
                                {field}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Bio */}
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-white/60 mb-2">Summary</h4>
                    <p className="text-sm">{selectedCandidate.bio_summary}</p>
                  </div>

                  {/* Reasoning */}
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-white/60 mb-2">AI Reasoning</h4>
                    <p className="text-sm text-white/70">{selectedCandidate.reasoning}</p>
                  </div>

                  {/* Pros */}
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-green-400 mb-2">✓ Strengths</h4>
                    <ul className="text-sm space-y-1">
                      {selectedCandidate.pros.map((pro, i) => (
                        <li key={i} className="text-white/70">• {pro}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Cons */}
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-orange-400 mb-2">⚠ Concerns</h4>
                    <ul className="text-sm space-y-1">
                      {selectedCandidate.cons.map((con, i) => (
                        <li key={i} className="text-white/70">• {con}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Interview Questions - Lazy loaded */}
                  <div>
                    <h4 className="text-sm font-semibold text-cyan-400 mb-2">💬 Interview Questions</h4>
                    {selectedCandidate.interview_questions && selectedCandidate.interview_questions.length > 0 ? (
                      <ul className="text-sm space-y-2">
                        {selectedCandidate.interview_questions.map((q, i) => (
                          <li key={i} className="text-white/70 bg-white/5 p-2 rounded-lg">{q}</li>
                        ))}
                      </ul>
                    ) : (
                      <button
                        onClick={() => loadInterviewQuestions(selectedCandidate.id)}
                        disabled={loadingQuestions}
                        className="btn-primary !py-2 !px-4 text-sm w-full"
                      >
                        {loadingQuestions ? "Generating..." : "Generate Questions"}
                      </button>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="mt-4 flex flex-wrap gap-2">
                    {selectedCandidate.sold_to_finance && (
                      <span className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-300">
                        💰 Finance Sales
                      </span>
                    )}
                    {selectedCandidate.is_founder && (
                      <span className="text-xs px-2 py-1 rounded-full bg-purple-500/20 text-purple-300">
                        🚀 Founder
                      </span>
                    )}
                    {selectedCandidate.startup_experience && (
                      <span className="text-xs px-2 py-1 rounded-full bg-blue-500/20 text-blue-300">
                        🏢 Startup Exp
                      </span>
                    )}
                    {selectedCandidate.enterprise_experience && (
                      <span className="text-xs px-2 py-1 rounded-full bg-orange-500/20 text-orange-300">
                        🏛️ Enterprise
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
